/// <reference types= "cypress" />

it('text Input', function() {

    cy.visit('http://uitestingplayground.com/textinput')
    cy.get('#newButtonName').type('madhu')
    // entering text into text field 'newButtonName'
    cy.get('#updatingButton').click()
    cy.get('#updatingButton').should('contain','madhu')
    //checking if the button text has name given as input in the text field


    
})