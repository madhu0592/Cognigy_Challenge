/// <reference types= "cypress" />

it('Progressbar', function() {

    cy.visit('http://uitestingplayground.com/progressbar')
    cy.get('#progressBar').contains('25%')
    // checking if starting position of progress bar is at 25% (it is always starting at 25)
    cy.get('#startButton').click()
    cy.get('#progressBar',{ timeout: 20000}).should('contain','75%')
    // waiting for progress bar to reach 75% using timeout as it is taking more time than 4s
    cy.get('#stopButton').click()
    //click stop when it reaches 75%

    
})