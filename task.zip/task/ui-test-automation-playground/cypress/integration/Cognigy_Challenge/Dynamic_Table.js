/// <reference types= "cypress" />


it("Dynamic table", function () {
      cy.visit("http://uitestingplayground.com/dynamictable");
      //cy.get('[role="table"] > :nth-child(2) > div > :nth-child(1)').invoke()
      cy.get('[role=table]')
      cy.get('.bg-warning').invoke('text').then((label) => { // storing yellow label text in variable 'x'
         cy.get('[role="columnheader"]').filter(':contains("CPU")').invoke('index').then((i) => { 
               // storing column number which contains CPU in variable 'i' 
              cy.log('CPU Column: '+i);
              cy.get('[role="cell"]').filter(':contains("Chrome")').parent().within(() => { 
                  // all searches are automatically rooted to the found tr element
                  cy.get('[role="cell"]').eq(i).invoke('text').then(cell =>{ 
                        //storing cell value in variable 'cell'
                        cy.log('Value of the Chrome CPU in the table: '+cell)
                        expect(label).to.contain(cell) 
                        // validating cell value 'label' with yellow label value 'cell'
                        
                  })
              })        
           })
      })
     
});
