/// <reference types= "cypress" />

it('AJAX data', function() {

    cy.visit('http://uitestingplayground.com/ajax')
  
    cy.get('#ajaxButton').click()
    
    cy.get('.bg-success',{ timeout: 20000}).should('be.visible').should('contain','Data loaded with AJAX get request')
    // here waiting for the success line to appear , used timeout as it is taking more time 
    // then checking if the line is as expected 'Data loaded with AJAX get request'


    

    
})