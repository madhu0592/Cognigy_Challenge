/// <reference types= "cypress" />

//const { contains } = require("cypress/types/jquery")

it('visibility', function() {

    cy.visit('http://uitestingplayground.com/visibility')

    cy.get('#hideButton').should('be.visible')
    cy.get('#transparentButton').should('not.be.hidden').should('be.visible')
    cy.get('#invisibleButton').should('not.be.hidden').should('be.visible')
    cy.get('#removedButton').should('not.be.hidden').should('be.visible')
    cy.get('#zeroWidthButton').should('not.be.hidden').should('be.visible')
    cy.get('#notdisplayedButton').should('not.be.hidden').should('be.visible')
    cy.get('#offscreenButton').should('not.be.hidden').should('be.visible')
    cy.get('#overlappedButton').should('not.be.hidden').should('be.visible')
    //validating if all buttons visible and exist before clicking hide button

    cy.get('#hideButton').click()

    cy.get('#transparentButton').should('not.be.visible').should('have.css','opacity','0')
    cy.get('#invisibleButton').should('not.be.visible')
    cy.get('#removedButton').should('not.exist')
    //removedButton is removed so doesnt exist anymore
    cy.get('#zeroWidthButton').should('not.be.visible').should('have.css', 'width', '0px')
    cy.get('#notdisplayedButton').should('not.be.visible')
    cy.get('#offscreenButton').should('not.be.disabled').should('be.visible')
    // overlappedbutton is still visible (somewhere in screen but transparent) because it has not disabled .btn:not(:disabled):not(.disabled) property 
    cy.get('#overlappedButton').should('not.be.disabled').should('be.visible')
    // overlappedbutton is still visible (in same position but transparent) because it has not disabled .btn:not(:disabled):not(.disabled) property 
    




    

    
})