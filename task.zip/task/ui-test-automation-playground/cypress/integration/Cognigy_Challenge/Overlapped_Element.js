/// <reference types= "cypress" />

it('overlapper element', function() {

     cy.visit('http://uitestingplayground.com/overlapped')
     cy.get('#id').click().type('123') // givig ranodom number in id field
     cy.get('[style="overflow-y: scroll; height:100px;"]').scrollTo("bottom") //scroll down to name field
     cy.get('#name').type('madhu') // giving name in name field
     
 })