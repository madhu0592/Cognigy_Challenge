/// <reference types= "cypress" />

//const { contains } = require("cypress/types/jquery")

it('sample app', function() {

    cy.visit('http://uitestingplayground.com/sampleapp')

    cy.get('[name$="UserName"]').type('madhu')
    cy.get('[name$="Password"]').type('pwd')

    cy.get('#login').click()
    
    cy.get('#loginstatus').contains('Welcome, madhu!').should('be.visible')
    //validating if login status has welcome message 
    cy.get('#loginstatus').contains("Invalid username/password").should('not.exist')
    
  
    
    
})